<?php include_once "./header.php" ;?>




<!-- Main Slider -->
<section class="main-slider">
		<div class="slider-box">
		
			<!-- Banner Carousel -->
			<div class="banner-carousel owl-theme owl-carousel">
			
				<!-- Slide -->
				<div class="slide">
                	<div class="image-layer" style="background-image:linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),url(assets/img/slider/slider-bg-4.jpg)"></div>
					<div class="auto-container" >
						<div class="content">
                        <h2>Building WEALTH<br>  Through Smart INVESTMENT</h2>
							<div class="text">We believe that through smart investments and strategic real estate choices, we can help our clients build wealth and live their best life</div>
							<div class="btns-box">
								<a href="#" class="theme-btn btn-style-one"><span class="txt">Know more</span></a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Slide -->
				<div class="slide">
                	<div class="image-layer" style="background-image:linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),url(assets/img/slider/slider-bg-3.jpg)"></div>
					<div class="auto-container" style="text-align: center;">
						<div class="content">
                        
                        <h2>Building WEALTH<br>  Through Smart INVESTMENT</h2>
							<div class="text" style="text-align: center;">We believe that through smart investments and strategic real estate choices, we can help our clients build wealth and live their best life</div>
							<div class="btns-box">
								<a href="#" class="theme-btn btn-style-one"><span class="txt">Know more</span></a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Slide -->
				<div class="slide">
                	<div class="image-layer" style="background-image:linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),url(assets/img/slider/slider-bg-4.jpg)"></div>
					<div class="auto-container" style="text-align: right;">
						<div class="content" style="text-align: right;">
							<h2>Building WEALTH<br>  Through Smart INVESTMENT</h2>
							<div class="text" style="text-align: right;">We believe that through smart investments and strategic real estate choices, we can help our clients build wealth and live their best life</div>
							<div class="btns-box">
								<a href="#" class="theme-btn btn-style-one"><span class="txt">Know more</span></a>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
		</div>
	</section>
	<!-- End Banner Section -->
	

    <!-- Testimonial Section -->
	<section class=""  style="background-color: #820eb7; height: 100px;">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title-two centered">
				<h2  style="color: #fff; padding-top: 25px;">ONYXZ SERVICES LTD</h2>
			</div>
			
        </div>
    </section>



    <!-- Story Section -->
    <section class="story-section">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Content Column -->
				<div class="content-column col-lg-6 col-md-12 col-sm-12" >
					<div class="inner-column">
						<h2 style="color: #820eb7; padding-bottom: 20px;">ABOUT US</h2>
						<div class="text">
							<p>Onyxz Service Ltd is a leading real estate investment company dedicated to helping our clients achieve their financial goals through smart property investments. With years of experience and a commitment to excellence, we have established a reputation as a trusted partner in the industry.</p>
							<p>Our team of experts has extensive knowledge of the real estate market and a deep understanding of investment strategies. We work closely with our clients to create customized investment plans that are tailored to their individual needs and goals.</p>
						</div>
                        <div class="btns-box" style=" padding-top: 20px;">
                            <a href="about.php" class="theme-btn btn-style-one"><span class="txt">Know more</span></a>
                        </div>
					</div>
				</div>
				
				<!-- Image Column -->
				<div class="image-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image" style="max-height: 300px;">
							<img src="assets/img/gallery/gallery-1-800x450.jpg" alt=""style="max-height: 300px;" />
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Story Section -->





<!-- Services Page Section -->
	<section class="services-page-section style-two" style="background-color: #f2f2f2;">
		<div class="auto-container">
			
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2 style="color: #820eb7;">OUR SERVICES</h2>
			</div>
			
			<div class="row clearfix">
				
				<!-- Service Block -->
				<div class="service-block-three style-two col-lg-4 col-md-4 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="housing.php"><img src="assets/img/project/project-6-440x280.jpg" style="height: 250px;" alt="" /></a>
						</div>
						<div class="lower-content">
							<h3><a href="housing.php">HOUSING</a></h3>
							<!-- <div class="text">We provides a range of housing services to meet the needs of today's homebuyers [...]</div>
							<a href="housing.php" class="read-more">Details</a> -->
						</div>
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block-three style-two col-lg-4 col-md-4 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="250ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="lands.php"><img src="assets/img/onyxz/land.png" style="height: 250px;" alt="" /></a>
						</div>
						<div class="lower-content">
							<h3><a href="lands.php">LANDS</a></h3>
							<!-- <div class="text">Onyxz Services Ltd is a leading real estate investment company that provides a wide range of land [...]</div>
							<a href="lands.php" class="read-more">Details</a> -->
						</div>
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block-three style-two col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="500ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="invest.php"><img src= "assets/img/onyxz/invest.jpg" style="height: 250px;" alt="" /></a>
						</div>
						<div class="lower-content">
							<h3><a href="invest.php">INVESTMENT</a></h3>
							<!-- <div class="text">We employs a talented team of industry leading professionals capable of self-performing [...]</div>
							<a href="invest.php" class="read-more">Details</a> -->
						</div>
					</div>
				</div>
				
				
			</div>

		</div>
	</section>
	<!-- End Story Section -->
	


<!-- Featured Section -->
<section class="featured-section" style="background-image: url('./assets/img/page/bg-iconbox.jpg')">
		<div class="auto-container">
			<!-- Title Box -->
			<div class="title-box">
				<h2>WHY CHOOSE US</h2>
			</div>
			
			<div class="row clearfix">
				
				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box" style = "">
								<span class="icon flaticon-hand-shake"></span>
							</div>
							
						</div>
						<div class="lower-content">
							<h3>CUSTOMER SATISFACTION</h3>
							<div class="text">We place a strong emphasis on customer satisfaction and strive to exceed expectations on every project.</div>
						</div>
					</div>
                </div>
				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12 cad" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box">
								<span class="icon flaticon-answer"></span>
							</div>
						</div>
						<div class="lower-content">
							<h3>EXPERIENCED TEAM</h3>
							<div class="text">Our team has years of experience in the industry, ensuring high-quality work and successful project completion..</div>
						</div>
					</div>
                </div>

				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12 cad" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box">
								<span class="icon flaticon-award-1"></span>
							</div>
						</div>
						<div class="lower-content">
							<h3>STRONG REPUTATION</h3>
							<div class="text">We have a strong reputation in the industry for delivering high-quality work and providing excellent customer service.</div>
						</div>
					</div>
                </div>
				
				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12 cad" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box">
								<span class="icon flaticon-call"></span>
							</div>
						</div>
						<div class="lower-content">
							<h3>LIVE SUPPORT</h3>
							<div class="text">Got any question? We are always active and ready to chat with. We are always ready to listen to you. You can also send mail to our support.</div>
						</div>
					</div>
                </div>
				
				
				
			</div>
			
		</div>
	</section>
	<!-- End Featured Section -->































    <!-- Testimonial Section -->
	<section class="testimonial-section"  style="background-color: #4c026d">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title-two centered">
				<h2  style="color: #fff;">FREQUENTLY ASKED QUESTIONS</h2>
				<!-- <div class="title-text">Thousands of people done interior</div> -->
			</div>

            <?php include_once "faq.php"; ?>
			
        </div>
    </section>








    

    <!-- Testimonial Section -->
	<section class="testimonial-section">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title-two centered">
				<h2  style="color: #820eb7;">TESTIMONIALS</h2>
				<!-- <div class="title-text">Thousands of people done interior</div> -->
			</div>
			
			<div class="testimonial-carousel owl-carousel owl-theme">
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box">
						<div class="content">
							
							<h3>Michale John</h3>
							<div class="title" style="color: #820eb7;">CEO COMPANY</div>
							<div class="text">"I recently had the opportunity to work with Onyxz Services Real Estate Investment Company and I was thoroughly impressed with their level of professionalism and expertise. Their team was knowledgeable, responsive, and always available to answer any questions I had throughout the process. "</div>
						</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box">
						<div class="content">
							
							<h3>RAPHEAL TONARD</h3>
							<div class="title" style="color: #820eb7;">REALTOR ONYXZ SERVICES LTD</div>
							<div class="text">"The team at Onyxz Services Ltd was excellent. They took the time to understand my investment goals and then tailored their services to meet those goals. I appreciated the way they were transparent about the market conditions and provided valuable insights that helped me make informed decisions."</div>
						</div>
					</div>
				</div>
				
				
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box">
						<div class="content" style="color: #820eb7;">
							
							<h3>Michale John</h3>
							<div class="title" style="color: #820eb7;">MANAGER COMPANY</div>
							<div class="text">"The team at Onyxz Services Ltd was excellent. They took the time to understand my investment goals and then tailored their services to meet those goals. I appreciated the way they were transparent about the market conditions and provided valuable insights that helped me make informed decisions."</div>
						</div>
					</div>
				</div>


                
				
			</div>
		</div>
	</section>
	<!-- End Testimonial Section -->
	





<!-- Testimonial Section -->
<section class="testimonial-section" style="background-color: #fff;">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title-two centered">
				<h2  style="color: #820eb7;">RECENT BLOG POST</h2>
				<!-- <div class="title-text">Thousands of people done interior</div> -->
			</div>
			
			<div class="testimonial-carousel owl-carousel owl-theme">
				
				


                <!-- News Block -->
                <div class="news-block col-lg-12 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="#"><img src="assets/img/onyxz/landi.jpg"  style="height: 250px;"alt="" /></a>
						</div>
						<div class="lower-content">
							<ul class="post-meta">
								<li>By <span>Admin</span></li>
								<li><i class="fa fa-calendar"></i> 27th Jan. 2023</li>
							</ul>

							<h3>Maximizing the Potential Value of Your Land Investment</h3>
                            <p>To maximize the potential value of your investment, you need to take a strategic approach...</p>
							<a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
						</div>
					</div>
				</div>
				



				 <!-- News Block -->
				<div class="news-block col-lg-12 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="#"><img src="assets/img/onyxz/2023.jpg"  style="height: 250px;" alt="" /></a>
						</div>
						<div class="lower-content">
							<ul class="post-meta">
								<li>By <span>Admin</span></li>
								<li><i class="fa fa-calendar"></i> 9th Jan. 2023</li>
							</ul>

							<h3>The Best Investments to Make in 2023</h3>
                            <p>As we enter 2023, many investors are looking to make smart financial decisions to grow their wealth and secure...</p>
							<a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
						</div>
					</div>
				</div>
				
                 <!-- News Block -->
				<div class="news-block col-lg-12 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="#"><img src="assets/img/onyxz/realinvest.jpg" style="height: 250px;" alt="" /></a>
						</div>
						<div class="lower-content">
							<ul class="post-meta">
								<li>By <span>Admin</span></li>
								<li><i class="fa fa-calendar"></i>  22nd Dec. 2022</li>
							</ul>

							<h3>The Benefits of Investing in Real Estate</h3>
                            <p>Investing in real estate has been a popular and profitable choice for many individuals and companies for decades...</p>
							<a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
						</div>
					</div>
				</div>


                <!-- News Block -->
				<div class="news-block col-lg-12 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<a href="#"><img src="assets/img/onyxz/div.jpg" style="height: 250px;" alt="" /></a>
						</div>
						<div class="lower-content">
							<ul class="post-meta">
								<li>By <span>Admin</span></li>
								<li><i class="fa fa-calendar"></i> 10th Nov. 2022</li>
							</ul>

							<h3>The Benefits of Diversifying Your Investment Portfolio</h3>
                            <p>Diversification is a key component of a successful investment strategy. By spreading your investments across different asset...</p>
							<a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
						</div>
					</div>
				</div>







			</div>
		</div>
	</section>
	<!-- End Testimonial Section -->
	











    	<!-- News Section -->
    <!-- <section class="news-section style-two">
        <div class="auto-container">
            <div class="sec-title-two centered">
                <h2  style="color: #820eb7;">RECENT BLOG POST</h2>
            </div>
            
            <div class="row clearfix">
                
                <div class="news-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="image">
                            <a href="#"><img src="assets/img/onyxz/landi.jpg"  style="height: 250px;"alt="" /></a>
                        </div>
                        <div class="lower-content">
                            <ul class="post-meta">
                                <li>By <span>Admin</span></li>
                                <li><i class="fa fa-calendar"></i> 27th Jan. 2023</li>
                            </ul>

                            <h3>Maximizing the Potential Value of Your Land Investment</h3>
                            <p>To maximize the potential value of your investment, you need to take a strategic approach...</p>
                            <a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
                        </div>
                    </div>
                </div>
                
                <div class="news-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="image">
                            <a href="#"><img src="assets/img/onyxz/realinvest.jpg" style="height: 250px;" alt="" /></a>
                        </div>
                        <div class="lower-content">
                            <ul class="post-meta">
                                <li>By <span>Admin</span></li>
                                <li><i class="fa fa-calendar"></i>  22nd Dec. 2022</li>
                            </ul>

                            <h3>The Benefits of Investing in Real Estate</h3>
                            <p>Investing in real estate has been a popular and profitable choice for many individuals and companies for decades...</p>
                            <a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
                        </div>
                    </div>
                </div>
                

                
                <div class="news-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="image">
                            <a href="#"><img src="assets/img/onyxz/div.jpg" style="height: 250px;" alt="" /></a>
                        </div>
                        <div class="lower-content">
                            <ul class="post-meta">
                                <li>By <span>Admin</span></li>
                                <li><i class="fa fa-calendar"></i> 10th Nov. 2022</li>
                            </ul>

                            <h3>The Benefits of Diversifying Your Investment Portfolio</h3>
                            <p>Diversification is a key component of a successful investment strategy. By spreading your investments across different asset...</p>
                            <a href="#" class="read-more">Read more <span class="icon flaticon-right-arrow-1"></span></a>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section> -->
	<!-- End News Section -->




<?php include_once "./footer.php" ;?>