
<?php include_once "./header.php" ;?>



  <!--Page Title-->
  <section class="page-title" style="background-image:url(assets/img/slider/slider-bg-3.jpg)">
    	<div class="auto-container">
        	<h2>About Us</h2>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">home</a></li>
                <li>About Us</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
	

    <!-- Story Section -->
    <section class="story-section">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Content Column -->
				<div class="content-column col-lg-6 col-md-12 col-sm-12" >
					<div class="inner-column">
						<h2 style="color: #820eb7; padding-bottom: 20px;">ABOUT US</h2>
						<div class="text">
							<p>Onyxz Service Ltd is a leading real estate investment company dedicated to helping our clients achieve their financial goals through smart property investments. With years of experience and a commitment to excellence, we have established a reputation as a trusted partner in the industry.</p>
							<p>Our team of experts has extensive knowledge of the real estate market and a deep understanding of investment strategies. We work closely with our clients to create customized investment plans that are tailored to their individual needs and goals.</p>
                            <p>At Onyxz Service Ltd, we believe in transparency and open communication. We are committed to keeping our clients informed every step of the way and providing the support they need to succeed.</p>
						</div>
                        <div class="btns-box" style=" padding-top: 20px;">
                            <a href="contact.php" class="theme-btn btn-style-one"><span class="txt">Contact Us Now</span></a>
                        </div>
					</div>
				</div>
				
				<!-- Image Column -->
				<div class="image-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image" style="max-height: 300px;">
							<img src="assets/img/gallery/gallery-1-800x450.jpg" alt=""style="max-height: 300px;" />
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Story Section -->


        <div class="auto-container">
            <div class="shop-single">
                <div class="product-details">
                    
                    
                    <!--Product Info Tabs-->
                    <div class="product-info-tabs">
                        <!--Product Tabs-->
                        <div class="prod-tabs tabs-box">
                        
                            <!--Tab Btns-->
                            <ul class="tab-btns tab-buttons clearfix">
                                <li data-tab="#prod-details" class="tab-btn active-btn">Our Vision</li>
                                <li data-tab="#prod-spec" class="tab-btn">Our Mission</li>
                                <li data-tab="#prod-reviews" class="tab-btn">Core Value</li>
                            </ul>
                            
                            <!--Tabs Container-->
                            <div class="tabs-content">
                                
                                <!--Tab / Active Tab-->
                                <div class="tab active-tab" id="prod-details">
                                    <div class="content">
                                        <p>To be the leading real estate investment company, providing innovative and sustainable solutions for our clients.</p>
                                        
                                    </div>
                                </div>
                                
                                <!--Tab-->
                                <div class="tab" id="prod-spec">
                                    <div class="content">
                                        <p>To create value for our clients by identifying and investing in attractive real estate opportunities, while delivering exceptional customer service and generating long-term growth and income.</p>
                                    </div>
                                </div>
                                
                                <!--Tab-->
                                <div class="tab" id="prod-reviews">
                                <div class="content">
								<p>Our Core Values includes:</p>
									<div class="row clearfix">
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-two">
												<li>-  Integrity</li>
												<li>-  Excellence</li>
											</ul>
										</div>
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-two">
												<li>-  Innovation</li>
												<li>-  Sustainability</li>
											</ul>
										</div>
									</div>
								</div>
                                        
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                    <!--End Product Info Tabs-->
                    
                </div>
            </div>
        </div>  



<!-- Featured Section -->
<section class="featured-section" style="background-image: url('./assets/img/page/bg-iconbox.jpg')">
		<div class="auto-container">
			<!-- Title Box -->
			<div class="title-box">
				<h2>WHY CHOOSE US</h2>
			</div>
			
			<div class="row clearfix">
				
				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box" style = "">
								<span class="icon flaticon-hand-shake"></span>
							</div>
							
						</div>
						<div class="lower-content">
							<h3>CUSTOMER SATISFACTION</h3>
							<div class="text">We place a strong emphasis on customer satisfaction and strive to exceed expectations on every project.</div>
						</div>
					</div>
                </div>
				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12 cad" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box">
								<span class="icon flaticon-answer"></span>
							</div>
						</div>
						<div class="lower-content">
							<h3>EXPERIENCED TEAM</h3>
							<div class="text">Our team has years of experience in the industry, ensuring high-quality work and successful project completion..</div>
						</div>
					</div>
                </div>

				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12 cad" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box">
								<span class="icon flaticon-award-1"></span>
							</div>
						</div>
						<div class="lower-content">
							<h3>STRONG REPUTATION</h3>
							<div class="text">We have a strong reputation in the industry for delivering high-quality work and providing excellent customer service.</div>
						</div>
					</div>
                </div>
				
				<!-- Feature Block -->
				<div class="feature-block col-lg-3 col-md-6 col-sm-12 cad" style="background-color: #fff;background-color: #fff; box-shadow: 0px 0px 15px rgba(0,0,0,0.15); padding: 30px 20px;">
                    
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon-outer">
							<div class="icon-box">
								<span class="icon flaticon-call"></span>
							</div>
						</div>
						<div class="lower-content">
							<h3>LIVE SUPPORT</h3>
							<div class="text">Got any question? We are always active and ready to chat with. We are always ready to listen to you. You can also send mail to our support.</div>
						</div>
					</div>
                </div>
				
				
				
			</div>
			
		</div>
	</section>
	<!-- End Featured Section -->




    <!-- Testimonial Section -->
	<section class="testimonial-section">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title-two centered">
				<h2  style="color: #820eb7;">TESTIMONIALS</h2>
				<!-- <div class="title-text">Thousands of people done interior</div> -->
			</div>
			
			<div class="testimonial-carousel owl-carousel owl-theme">
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box">
						<div class="content">
							
							<h3>Michale John</h3>
							<div class="title" style="color: #820eb7;">CEO COMPANY</div>
							<div class="text">"I recently had the opportunity to work with Onyxz Services Real Estate Investment Company and I was thoroughly impressed with their level of professionalism and expertise. Their team was knowledgeable, responsive, and always available to answer any questions I had throughout the process. "</div>
						</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box">
						<div class="content">
							
							<h3>RAPHEAL TONARD</h3>
							<div class="title" style="color: #820eb7;">REALTOR ONYXZ SERVICES LTD</div>
							<div class="text">"The team at Onyxz Services Ltd was excellent. They took the time to understand my investment goals and then tailored their services to meet those goals. I appreciated the way they were transparent about the market conditions and provided valuable insights that helped me make informed decisions."</div>
						</div>
					</div>
				</div>
				
				
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box">
						<div class="content" style="color: #820eb7;">
							
							<h3>Michale John</h3>
							<div class="title" style="color: #820eb7;">MANAGER COMPANY</div>
							<div class="text">"The team at Onyxz Services Ltd was excellent. They took the time to understand my investment goals and then tailored their services to meet those goals. I appreciated the way they were transparent about the market conditions and provided valuable insights that helped me make informed decisions."</div>
						</div>
					</div>
				</div>


                
				
			</div>
		</div>
	</section>
	<!-- End Testimonial Section -->
	












<?php include_once "./footer.php" ;?>
