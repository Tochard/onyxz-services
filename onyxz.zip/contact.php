<?php include_once "./header.php" ;?>



 




  <!--Page Title-->
  <section class="page-title" style="background-image:url(assets/img/slider/slider-bg-3.jpg)">
    	<div class="auto-container">
        	<h2>Contact Us</h2>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">home</a></li>
                <li>Contact Us</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
	
	<!-- Contact Form Section -->
	<section class="contact-form-section" style="background-image:url(assets/img/onyxz/contact.png)">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title">
				<h2>Get In Touch</h2>
				<div class="text">For more information on our services please contact us via this contact form...</div>
			</div>
			
			<div class="row clearfix">
				
				<!-- Form Column -->
				<div class="form-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column">
						
						<!-- Contact Form -->
						<div class="contact-form">
						<?php
                                    $url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                    if (strpos($url, 'Successful')==true){
                                    ?>
                                        <script src="js/sweetalert.min.js"></script>

                                        <script>
                                        swal({
                                          title: "Successful",
                                          text: "Your message is sent",
                                          icon: "success",
                                          button: "Ok",
                                        });
                                        </script> 
                                          
                                <?php } ?>  
								
							<!--Contact Form-->
							<form method="post" action="mail.php" id="contact-form">
								<div class="row clearfix">
									<div class="form-group col-lg-6 col-md-6 col-sm-12">
										<input type="text" name="name" placeholder="Your name" required>
									</div>
									
									<div class="form-group col-lg-6 col-md-6 col-sm-12">
										<input type="text" name="email" placeholder="Email address" required>
									</div>
									
									<div class="form-group col-lg-12 col-md-12 col-sm-12">
										<input type="text" name="subject" placeholder="Subject" required>
									</div>
									
									<div class="form-group col-lg-12 col-md-12 col-sm-12">
										<textarea name="message" placeholder="Message"></textarea>
									</div>
									
									<div class="form-group col-lg-12 col-md-12 col-sm-12">
										<button class="theme-btn btn-style-one" type="submit" name="submit"><span class="txt">Submit now</span></button>
									</div>
								</div>
							</form>
						</div>
						
					</div>
				</div>
				
				<!-- Info Column -->
				<div class="info-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						
						<!-- Contact Info List -->
						<ul class="contact-info-list">
							<li><strong>Address :</strong><br> 18B, Robert Street, Magodo Phase 2, Shangisha, Lagos State, Nigeria.</li>
						</ul>
						<!-- Contact Info List -->
						<ul class="contact-info-list">
							<li><strong>Phone : </strong><a href="tel:+234 908 8998 821">+234 908 8998 821</a></li>
							<li><strong>Email : </strong><a href="mailto:Support@onyxzservicesltd.com">Support@onyxzservicesltd.com</a></li>
						</ul>
						<!-- Contact Info List -->
						<ul class="contact-info-list">
							<li><strong>Opening Hours :</strong><br>8:00 AM – 5:00 PM <br> Monday – Saturday</li>
						</ul>
						
					</div>
				</div>
				
			</div>
			
		</div>
	</section>
	<!-- End Contact Form Section -->
	
















<?php include_once "./footer.php" ;?>