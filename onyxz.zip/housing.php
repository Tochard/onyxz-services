<?php include_once "./header.php" ;?>








  <!--Page Title-->
  <section class="page-title" style="background-image:url(assets/img/onyxz/invest.jpg)">
    	<div class="auto-container">
        	<h2>Housing</h2>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">home</a></li>
                <li>Housing</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
	

	<!--Shop Single Section-->
    <section class="shop-single-section">
    	<div class="auto-container">
        	
            <div class="shop-single">
                <div class="product-details">
                    
                    <!--Basic Details-->
                    <div class="basic-details">
                        <div class="row clearfix">
                            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                <figure class="image-box"><a href="assets/img/onyxz/invest.jpg" class="lightbox-image" title="Image Caption Here"><img src="assets/img/onyxz/invest.jpg" alt=""></a></figure>
                            </div>
                            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	<div class="inner-column">
                                    <h4>HOUSING</h4>
                                    <div class="text">Onyxz Services Ltd is a leading real estate investment company that offers a wide range of housing services to its clients. We understand the importance of providing high-quality and affordable housing solutions, and we are committed to delivering the best possible outcomes for our clients.
                                </div>
                                <div class="inner-column">
                                    <h4>OUR HOUSING SERVICES INCLUDES:</h4>
                                    <div class="text">At Onyxz Services Ltd, we are dedicated to helping our clients achieve their housing goals. Our team of experts will work with you every step of the way, from residential development to property management to homeowner services. Contact us today to learn more about our housing services.</div>
                                    
                                    
                            
                                </div>
                            </div>
                        </div>

                        <div class="row clearfix">
                        <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	
                                <div class="inner-column">
                                    
                                    <div class="price"> <span>Residential Development: </span></div>
                                    <div class="text">Our team of experts will help you identify and develop residential properties that meet your investment goals. We have extensive knowledge of local regulations and market trends, and we will work with you to ensure a successful development project.</div>
                                    <div class="price"> <span>Property Management:</span></div>
                                    <div class="text">Onyxz Services Ltd offers a comprehensive property management service for residential properties. Our experienced team will handle all aspects of property management, including maintenance, leasing, and financial reporting, to ensure that your investment performs at its best.</div>
                                    
                                    
                            
                                </div>
                            </div>
                            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	
                                <div class="inner-column">
                                    <div class="price"> <span>Affordable Housing Solutions: </span></div>
                                    <div class="text">At Onyxz Services Ltd, we believe that everyone deserves access to affordable and quality housing. That's why we offer a range of affordable housing solutions designed to meet the needs of low and moderate-income families.</div>
                                    <div class="price"> <span>Homeowner Services:</span></div>
                                    <div class="text">If you're a homeowner, Onyxz Services Ltd can help you with all your housing needs. Our team of experts can assist you with home renovations, property maintenance, and financial planning, to help you get the most out of your investment.</div>
                                    
                            
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Basic Details-->
                    
                    
                </div>
            </div>
            
        </div>
    </section>
    <!--End Shop Single Section-->
	
	








<?php include_once "./footer.php" ;?>