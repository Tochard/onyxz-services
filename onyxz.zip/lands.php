<?php include_once "./header.php" ;?>








  <!--Page Title-->
  <section class="page-title" style="background-image:url(assets/img/onyxz/landi.jpg)">
    	<div class="auto-container">
        	<h2>Lands</h2>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">home</a></li>
                <li>Lands</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
	

	<!--Shop Single Section-->
    <section class="shop-single-section">
    	<div class="auto-container">
        	
            <div class="shop-single">
                <div class="product-details">
                    
                    <!--Basic Details-->
                    <div class="basic-details">
                        <div class="row clearfix">
                            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                <figure class="image-box"><a href="assets/img/onyxz/landi.jpg" class="lightbox-image" title="Image Caption Here"><img src="assets/img/onyxz/landi.jpg" alt=""></a></figure>
                            </div>
                            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	<div class="inner-column">
                                    <h4>LANDS</h4>
                                    <div class="text">Onyxz Services Ltd is a leading real estate investment company that provides a wide range of land services to its clients. We are committed to delivering the highest level of service and expertise to help our clients make informed decisions about their real estate investments. </div>
                                    
                                </div>
                                <div class="inner-column">
                                    <h4>OUR INVESTMENT SERVICES INCLUDES:</h4>
                                    <div class="text">At Onyxz Services Ltd, we are dedicated to helping our clients achieve their real estate investment goals. Our team of experts will work with you every step of the way, from land acquisition to site development to property management. Contact us today to learn more about our land services. </div>
                                    
                                    
                            
                                </div>
                            </div>
                        </div>

                        <div class="row clearfix">
                        <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	
                                <div class="inner-column">
                                    
                                    <div class="price"> <span>Land Acquisition: </span></div>
                                    <div class="text">Our team of experts will assist you in identifying and acquiring the perfect piece of land for your investment needs. We have extensive knowledge of local markets and regulations, and we will work closely with you to ensure a smooth and successful acquisition process.</div>
                                    <div class="price"> <span>Due Diligence: </span></div>
                                    <div class="text">Before making a real estate investment, it is essential to perform thorough due diligence. Onyxz Services Ltd will help you gather all the necessary information to make an informed decision, including conducting environmental assessments, reviewing title documents, and negotiating any necessary agreements.</div>
                                    
                                    
                            
                                </div>
                            </div>
                            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	
                                <div class="inner-column">
                                    <div class="price"> <span>Site Development: </span></div>
                                    <div class="text">Once you have acquired your land, Onyxz Services Ltd can help you with site development, including planning, design, and construction management. We have a proven track record of delivering projects on time and within budget, and we will work closely with you to ensure your vision becomes a reality.</div>
                                    <div class="price"> <span>Property Management:</span></div>
                                    <div class="text">After your investment is complete, Onyxz Services Ltd offers a comprehensive property management service to ensure your investment performs at its best. Our experienced team will manage all aspects of your property, including maintenance, leasing, and financial reporting.</div>
                                    
                            
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Basic Details-->
                    
                    
                </div>
            </div>
            
        </div>
    </section>
    <!--End Shop Single Section-->
	
	








<?php include_once "./footer.php" ;?>