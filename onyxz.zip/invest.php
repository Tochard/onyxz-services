<?php include_once "./header.php" ;?>








  <!--Page Title-->
  <section class="page-title" style="background-image:url(assets/img/onyxz/invest.jpg)">
    	<div class="auto-container">
        	<h2>Investment</h2>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">home</a></li>
                <li>Investment</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
	

	<!--Shop Single Section-->
    <section class="shop-single-section">
    	<div class="auto-container">
        	
            <div class="shop-single">
                <div class="product-details">
                    
                    <!--Basic Details-->
                    <div class="basic-details">
                        <div class="row clearfix">
                            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                <figure class="image-box"><a href="assets/img/onyxz/invest.jpg" class="lightbox-image" title="Image Caption Here"><img src="assets/img/onyxz/invest.jpg" alt=""></a></figure>
                            </div>
                            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	<div class="inner-column">
                                    <h4>INVESTMENT</h4>
                                    <div class="text">Onyxz Services Ltd is a leading real estate investment company that offers a wide range of investment services to its clients. We are dedicated to helping our clients achieve their investment goals and to maximizing their returns.</div>
                                    
                                </div>
                                <div class="inner-column">
                                    <h4>OUR LAND SERVICES INCLUDES:</h4>
                                    <div class="text">At Onyxz Services Ltd, we are dedicated to helping our clients achieve their investment goals. Our team of experts will work with you every step of the way, from investment advisory to asset management to real estate market research. Contact us today to learn more about our investment services. </div>
                                    
                                    
                            
                                </div>
                            </div>
                        </div>

                        <div class="row clearfix">
                        <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	
                                <div class="inner-column">
                                    
                                    <div class="price"> <span>Investment Advisory: </span></div>
                                    <div class="text">Our team of experts will work with you to understand your investment goals and to develop a customized investment strategy that meets your needs. We have extensive knowledge of local and global real estate markets, and we will provide you with the information and advice you need to make informed investment decisions..</div>
                                    <div class="price"> <span>Asset Management:</span></div>
                                    <div class="text">Onyxz Services Ltd offers a comprehensive asset management service that will help you optimize the performance of your real estate investments. Our team of experts will handle all aspects of asset management, including property management, leasing, and financial reporting, to ensure that your investments perform at their best.</div>
                                    
                                    
                            
                                </div>
                            </div>
                            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                            	
                                <div class="inner-column">
                                    <div class="price"> <span>Real Estate Funds: </span></div>
                                    <div class="text">If you're looking for a more passive investment option, Onyxz Services Ltd offers real estate funds that give you access to a diversified portfolio of real estate assets. Our real estate funds are managed by experienced investment professionals and are designed to deliver attractive returns with a lower level of risk.</div>
                                    <div class="price"> <span>Real Estate Market Research:</span></div>
                                    <div class="text">At Onyxz Services Ltd, we believe that knowledge is power. That's why we offer a range of real estate market research services, including market analysis, market trends, and investment insights. Our market research services are designed to help you make informed investment decisions.</div>
                                    
                            
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Basic Details-->
                    
                    
                </div>
            </div>
            
        </div>
    </section>
    <!--End Shop Single Section-->
	
	








<?php include_once "./footer.php" ;?>